---
name: frete-entrega
description: Como tratar perguntas de frete e entrega local: nunca cotar valor, o produtor confirma a taxa no app, pedir o endereço completo, pedir para aguardar e registrar no lead.
matcher:
  any_keywords: [frete, entrega, quanto fica a entrega, onde fica, onde retirar, retirada, endereço, motoboy, uber, 99, entrega em juazeiro, entrega em barbalha, entrega em crato]
  probe_keywords: [quanto fica, qual o valor, onde fica, onde retirar]
---
Frete (entrega local): Nunca cite um valor de frete e nunca diga que você vai abrir o aplicativo. A taxa é confirmada pelo produtor no app. Quando perguntarem o frete: peça o endereço completo (rua, número, bairro, cidade), diga que vai verificar e chamar o produtor para entregar a informação, peça para a pessoa aguardar, e registre tudo no lead (anotação: endereço, destino, o que foi pedido). A tabela de frete está sendo construída e ainda não tem valores — nunca cite um valor da tabela hoje. Quem paga a entrega é o comprador; se a TuttiBom chamar o motoboy, só com a taxa PAGA ANTES pelo comprador. Retirada no Crato não tem taxa — mas NUNCA informe o endereço da retirada antes de a compra estar fechada e o pagamento confirmado. Fora da área (Correios): outro caminho, com intervenção humana — não é cotação de Uber/99.
