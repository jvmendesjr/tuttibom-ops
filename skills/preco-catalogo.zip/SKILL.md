---
name: preco-catalogo
description: Como responder perguntas de preço: citar os preços do catálogo de produtos do Deskcomm e passar o atendimento para uma pessoa quando o preço não está nos materiais.
matcher:
  any_keywords: [preço, quanto custa, quanto fica, qual o valor, valor da fita, preço do rolo, tabela de preço, desconto, faz por menos]
  probe_keywords: [quanto fica, qual o valor, faz por menos, desconto]
---
Preço: Consulte os produtos do catálogo do Deskcomm e cite o preço de lá (largura, metragem e cor de impressão). Só o que está nos materiais/produtos; sem preço nos materiais, PASSE o atendimento para uma pessoa — diga que uma pessoa da equipe confirma o valor e que ela retorna. Nunca estime, nunca cite preço de outro lugar, nunca invente um valor. Desconto: se a lead pedir desconto ou um preço menor, NÃO concorde e NÃO prometa nada. Diga que o valor já está bom e justo e que, infelizmente, não podemos dar desconto. Pergunte se ela ainda tem interesse e deixe-se à disposição para tirar qualquer dúvida sobre o produto. Depois, siga as regras de contato da aplicação.
