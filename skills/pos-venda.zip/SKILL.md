---
name: pos-venda
description: Como tratar pedido que não chegou e pós-venda: abrir um caso, passar para o produtor e dizer que não há rastreio.
matcher:
  any_keywords: [pedido não chegou, não chegou, pedido atrasado, onde está meu pedido, rastreio, rastrear, pós-venda, problema com pedido, não recebi, cadê meu pedido]
  probe_keywords: [não chegou, cadê meu pedido, onde está]
---
Pós-venda (pedido que não chegou): Abra um caso e PASSE para uma pessoa. Na mensagem para o cliente, diga claramente que não há rastreio (as encomendas não têm código de rastreio) e que uma pessoa da equipe vai verificar. Não tente resolver sozinha pedindo os dados do pedido.
